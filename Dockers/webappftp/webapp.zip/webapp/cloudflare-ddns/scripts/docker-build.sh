#!/bin/bash
docker build --platform linux/amd64 --tag timothyjmiller/cloudflare-ddns:latest ../
