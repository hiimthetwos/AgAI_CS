#!/bin/bash
docker run timothyjmiller/cloudflare-ddns:latest
