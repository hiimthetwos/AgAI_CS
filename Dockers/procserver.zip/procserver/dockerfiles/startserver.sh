#!/bin/bash

python /agai/localprocqueue.py
